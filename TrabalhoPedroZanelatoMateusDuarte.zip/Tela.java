package a;

import javax.swing.JMenuItem;
import javax.swing.JPanel;

public interface Tela {
	public JPanel getTela();
	public JMenuItem getSource();
	public String getMensagemStatus();
}

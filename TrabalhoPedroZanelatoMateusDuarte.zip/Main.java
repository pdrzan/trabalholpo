package a;

import javax.swing.JFrame;

public class Main extends JFrame{
    public static void main(String[] args){
        Basquete basquete = new Basquete();
    }
}
